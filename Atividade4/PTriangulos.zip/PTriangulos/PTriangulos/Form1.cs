﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulos
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBoxA_Validated(object sender, EventArgs e) // Validação Lado A
        {
            if (!double.TryParse(textBoxA.Text, out LadoA))
            {
                MessageBox.Show("Digite Números Validos");

            }

        }

        private void Calcular_Click(object sender, EventArgs e) // Validação Calcular
        {
            if ((LadoA < (LadoB + LadoC)) &&
        (LadoA > Math.Abs(LadoB - LadoC)) &&
            (LadoB < (LadoA + LadoC)) &&
                    (LadoB > Math.Abs(LadoA - LadoC)) &&
                        (LadoC < (LadoA + LadoB)) &&
                            (LadoC > Math.Abs(LadoA - LadoB)))
            {

                if ((LadoA == LadoB) && (LadoB == LadoC))
                {
                    MessageBox.Show("Triângulo Equilátero.");
                }
                else
                    if ((LadoA == LadoB) || (LadoB == LadoC) || (LadoA == LadoC))
                {
                    MessageBox.Show("Triângulo Isósceles.");
                }
                else
                {
                    MessageBox.Show("Triângulo Escaleno.");
                }
            }
            else
            {
                MessageBox.Show("Os números informados não formam um triângulo. Tente Novamente.");
            }
        }

        private void Limpar_Click(object sender, EventArgs e) // limpar
        {
            textBoxA.Clear();
            textBoxB.Clear();
            textBoxC.Clear();
        }

        private void Fechar_Click(object sender, EventArgs e) // Fechar
        {
            Close();
        }

        private void textBoxB_Validated(object sender, EventArgs e) // Validação Lado B
        {
            if (!double.TryParse(textBoxB.Text, out LadoB))
            {
                MessageBox.Show("Digite Números Validos");

            }
        }

        private void textBoxC_Validated(object sender, EventArgs e) // Validação Lado C
        {
            if (!double.TryParse(textBoxC.Text, out LadoC))
            {
                MessageBox.Show("Digite Números Validos");

            }
        }
    }
}
